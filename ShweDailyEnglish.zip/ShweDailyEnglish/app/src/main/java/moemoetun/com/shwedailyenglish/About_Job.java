package moemoetun.com.shwedailyenglish;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;

public class About_Job extends AppCompatActivity {

    ListView lv;
    Context context;


    ArrayList prgmName;
    public static int [] prgmImages={
            R.drawable.star,
            R.drawable.star1,
            R.drawable.star2,
            R.drawable.star3,
            R.drawable.star4,
            R.drawable.star5,
            R.drawable.star6,
            R.drawable.star7,
            R.drawable.star,
            R.drawable.star1,
            R.drawable.star2,
            R.drawable.star3,
            R.drawable.star4,
            R.drawable.star5,
            R.drawable.star6,
            R.drawable.star7,
            R.drawable.star,
            R.drawable.star,
            R.drawable.star1,
            R.drawable.star2,
            R.drawable.star3


    };


    public static String [] prgmNameList={


            "✪ Choosing a job",
            "✪ Money and Happiness",
            "✪ A job at 16",
            "✪ Starting a business",
            "✪ You have to get a job",
            "✪ Finding a job",
            "✪ Job interview",
            "✪ Being a teacher",
            "✪ The first job",
            "✪ A bad first day of work",
            "✪ Lunch break ",
            "✪ Night shift",
            "✪ Customers are always right",
            "✪ A bad customer",
            "✪ Framed",
            "✪ Should I move?",
            "✪ A doctor or a nurse",
            "✪ Overtime",
            "✪ Asking for a raise",
            "✪ Night owl",
            "✪ No Content"
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_about__job);



        MobileAds.initialize(getApplicationContext(), "ca-app-pub-4137439985376631/8428273307");
        AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        context=this;

        lv=(ListView) findViewById(R.id.ListView_job);
        lv.setAdapter(new CustomAdapter9(this, prgmNameList,prgmImages));


    }

}
