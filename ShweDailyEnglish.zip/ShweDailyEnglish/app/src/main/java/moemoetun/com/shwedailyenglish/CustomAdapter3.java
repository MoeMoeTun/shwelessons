package moemoetun.com.shwedailyenglish;

/**
 * Created by Arakan Tiger on 1/29/2017.
 */
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import static android.R.attr.typeface;

public class CustomAdapter3 extends BaseAdapter{
    String [] result;
    Context context;
    int [] imageId;
    private static LayoutInflater inflater=null;
    public CustomAdapter3(moemoetun.com.shwedailyenglish.model_verb model_verb, String[] prgmNameList, int[] prgmImages) {
        // TODO Auto-generated constructor stub
        result=prgmNameList;
        context=model_verb;
        imageId=prgmImages;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return result.length;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }




    public class Holder {

        TextView tv;
        ImageView img;

    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder=new Holder();
        View rowView;
        rowView = inflater.inflate(R.layout.model_verb_programlist, null);
        holder.tv=(TextView) rowView.findViewById(R.id.textView1);
        AssetManager assetManager = context.getAssets();
        final Typeface tvFont = Typeface.createFromAsset(assetManager, "fonts/Zawgyi-One.ttf");
        holder.tv.setTypeface(tvFont);

        holder.img=(ImageView) rowView.findViewById(R.id.imageView1);
        holder.tv.setText(result[position]);
        holder.img.setImageResource(imageId[position]);
        rowView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Toast.makeText(context, "You Clicked "+result[position], Toast.LENGTH_LONG).show();

                if(position==0){
                    Intent voca0 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.Can.class);
                    context.startActivity(voca0);
                }


                if(position==1){
                    Intent voca1 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.should.class);
                    context.startActivity(voca1);
                }


                if(position==2){
                    Intent voca2 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.May_Positive.class);
                    context.startActivity(voca2);
                }



                if(position==3){
                    Intent voca3 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.might.class);
                    context.startActivity(voca3);
                }


                if(position==4){
                    Intent voca4 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.Will_Tab3.class);
                    context.startActivity(voca4);
                }



                if(position==5){
                    Intent voca5 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.would.class);
                    context.startActivity(voca5);
                }



                if(position==6){
                    Intent voca6 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.shall.class);
                    context.startActivity(voca6);
                }


                if(position==7){
                    Intent voca7 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.Must.class);
                    context.startActivity(voca7);
                }


                if(position==8){
                    Intent voca7 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.model_verb_whquestion.class);
                    context.startActivity(voca7);
                }


                if(position==9){
                    Intent voca7 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.model_verb_passive_voice.class);
                    context.startActivity(voca7);
                }


                if(position==10){
                    Intent voca7 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.mode_verb_adjective.class);
                    context.startActivity(voca7);
                }


                if(position==11){
                    Intent voca7 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.model_verb_prepostition.class);
                    context.startActivity(voca7);
                }





            }
        });
        return rowView;
    }




}