package moemoetun.com.shwedailyenglish;

/**
 * Created by Arakan Tiger on 1/29/2017.
 */
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class CustomAdapter10 extends BaseAdapter{
    String [] result;
    Context context;
    int [] imageId;
    private static LayoutInflater inflater=null;
    public CustomAdapter10(moemoetun.com.shwedailyenglish.House house, String[] prgmNameList, int[] prgmImages) {
        // TODO Auto-generated constructor stub
        result=prgmNameList;
        context=house;
        imageId=prgmImages;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return result.length;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }




    public class Holder {

        TextView tv;
        ImageView img;

    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder=new Holder();
        View rowView;
        rowView = inflater.inflate(R.layout.about_job_programlist, null);
        holder.tv=(TextView) rowView.findViewById(R.id.textView1);
        AssetManager assetManager = context.getAssets();
        final Typeface tvFont = Typeface.createFromAsset(assetManager, "fonts/Zawgyi-One.ttf");
        holder.tv.setTypeface(tvFont);

        holder.img=(ImageView) rowView.findViewById(R.id.imageView1);
        holder.tv.setText(result[position]);
        holder.img.setImageResource(imageId[position]);
        rowView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Toast.makeText(context, "You Clicked "+result[position], Toast.LENGTH_LONG).show();



                if(position==0){
                    Intent voca0 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.key_confusion.class);
                    context.startActivity(voca0);
                }

                if(position==1){
                    Intent voca1 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.nice_blue_color.class);
                    context.startActivity(voca1);
                }

                if(position==2){
                    Intent voca2 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.Broken_window.class);
                    context.startActivity(voca2);
                }

                if(position==3){
                    Intent voca3 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.Air_conditioning.class);
                    context.startActivity(voca3);
                }

                if(position==4){
                    Intent voca4 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.Nails_inthewall.class);
                    context.startActivity(voca4);
                }

                if(position==5){
                    Intent voca5 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.Christmas_decoration.class);
                    context.startActivity(voca5);
                }

                if(position==6){
                    Intent voca6 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.outdoor_barbecue.class);
                    context.startActivity(voca6);
                }

                if(position==7){
                    Intent voca7 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.Roommates.class);
                    context.startActivity(voca7);
                }

                if(position==8){
                    Intent voca8 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pets_inthehouse.class);
                    context.startActivity(voca8);
                }

                if(position==9){
                    Intent voca9 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.lats_mortgage.class);
                    context.startActivity(voca9);
                }

                if(position==10){
                    Intent voca10 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.closet_space.class);
                    context.startActivity(voca10);
                }

                if(position==11){
                    Intent voca11 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.big_announcement.class);
                    context.startActivity(voca11);
                }

                if(position==12){
                    Intent voca12 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.Noisy_neighbour.class);
                    context.startActivity(voca12);
                }



            }
        });
        return rowView;
    }




}