package moemoetun.com.shwedailyenglish;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;


public class Banking extends AppCompatActivity {

    String [] friends= {


            "✪ Different Bank Accounts",
            "✪ Opening a Bank Account",
            "✪ ATM Card Being Declined",
            "✪ Making a Deposit",
            "✪ Making a Withdrawal",
            "✪ Transferring Money",
            "✪ Over withdrawal",
            "✪ Using ATM",
            "✪ Asking About Fees",
            "✪ Paying Fees",
            "✪ No content",



    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_banking);
        ListView listView = (ListView) findViewById(R.id.ListView_banking);


        MobileAds.initialize(getApplicationContext(), "ca-app-pub-3940256099942544~3347511713");
        AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, friends );

        listView.setAdapter(adapter);

        //get itemClick
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                String friends = (String) adapterView.getItemAtPosition(position);
                Toast.makeText(view.getContext(),"Hello" +friends+ "", Toast.LENGTH_SHORT).show();


                if(position==0){
                    Intent voca1 = new Intent(view.getContext(), bank1.class);
                    startActivity(voca1);
                }

                if(position==1){
                    Intent voca2 = new Intent(view.getContext(), bank2.class);
                    startActivity(voca2);
                }


                if(position==2){
                    Intent voca3 = new Intent(view.getContext(), bank3.class);
                    startActivity(voca3);
                }

                if(position==3){
                    Intent voca4 = new Intent(view.getContext(), bank4.class);
                    startActivity(voca4);
                }

                if(position==4){
                    Intent voca5 = new Intent(view.getContext(), bank5.class);
                    startActivity(voca5);
                }

                if(position==5){
                    Intent voca5 = new Intent(view.getContext(), bank6.class);
                    startActivity(voca5);
                }

                if(position==6){
                    Intent voca6 = new Intent(view.getContext(), bank7.class);
                    startActivity(voca6);
                }

                if(position==7){
                    Intent voca7 = new Intent(view.getContext(), bank8.class);
                    startActivity(voca7);
                }

                if(position==8){
                    Intent voca8 = new Intent(view.getContext(), bank9.class);
                    startActivity(voca8);
                }
                if(position==9){
                    Intent voca9 = new Intent(view.getContext(), bank10.class);
                    startActivity(voca9);
                }

            }
        });
    }


}
