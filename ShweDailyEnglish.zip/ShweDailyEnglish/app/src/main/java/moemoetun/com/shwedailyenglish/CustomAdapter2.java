package moemoetun.com.shwedailyenglish;

/**
 * Created by Arakan Tiger on 1/29/2017.
 */
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import static android.R.attr.typeface;

public class CustomAdapter2 extends BaseAdapter{
    String [] result;
    Context context;
    int [] imageId;
    private static LayoutInflater inflater=null;
    public CustomAdapter2(moemoetun.com.shwedailyenglish.speaking_patterns speakingPatterns, String[] prgmNameList, int[] prgmImages) {
        // TODO Auto-generated constructor stub
        result=prgmNameList;
        context=speakingPatterns;
        imageId=prgmImages;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return result.length;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }




    public class Holder {

        TextView tv;
        ImageView img;

    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        Holder holder=new Holder();
        View rowView;
        rowView = inflater.inflate(R.layout.speaking_pattern_program, null);
        holder.tv=(TextView) rowView.findViewById(R.id.textView1);
        AssetManager assetManager = context.getAssets();
        final Typeface tvFont = Typeface.createFromAsset(assetManager, "fonts/Zawgyi-One.ttf");
        holder.tv.setTypeface(tvFont);

        holder.img=(ImageView) rowView.findViewById(R.id.imageView1);
        holder.tv.setText(result[position]);
        holder.img.setImageResource(imageId[position]);
        rowView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Toast.makeText(context, "You Clicked "+result[position], Toast.LENGTH_LONG).show();


                if(position==0){
                    Intent voca0 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern1.class);
                    context.startActivity(voca0);
                }

                if(position==1){
                    Intent voca1 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern2.class);
                    context.startActivity(voca1);
                }

                if(position==2){
                    Intent voca2 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern3.class);
                    context.startActivity(voca2);
                }

                if(position==3){
                    Intent voca3 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern4.class);
                    context.startActivity(voca3);
                }

                if(position==4){
                    Intent voca4 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern5.class);
                    context.startActivity(voca4);
                }

                if(position==5){
                    Intent voca5 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern6.class);
                    context.startActivity(voca5);
                }

                if(position==6){
                    Intent voca6 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern7.class);
                    context.startActivity(voca6);
                }

                if(position==7){
                    Intent voca7 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern8.class);
                    context.startActivity(voca7);
                }

                if(position==8){
                    Intent voca8 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern9.class);
                    context.startActivity(voca8);
                }

                if(position==9){
                    Intent voca9 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern10.class);
                    context.startActivity(voca9);
                }

                if(position==10){
                    Intent voca10 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern11.class);
                    context.startActivity(voca10);
                }

                if(position==11){
                    Intent voca11 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern12.class);
                    context.startActivity(voca11);
                }


                if(position==12){
                    Intent voca12 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern13.class);
                    context.startActivity(voca12);
                }


                if(position==13){
                    Intent voca13 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern14.class);
                    context.startActivity(voca13);
                }

                if(position==14){
                    Intent voca14 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern15.class);
                    context.startActivity(voca14);
                }

                if(position==15){
                    Intent voca15 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern16.class);
                    context.startActivity(voca15);
                }

                if(position==16){
                    Intent voca16 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern17.class);
                    context.startActivity(voca16);
                }

                if(position==17){
                    Intent voca17 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern18.class);
                    context.startActivity(voca17);
                }

                if(position==18){
                    Intent voca18 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern19.class);
                    context.startActivity(voca18);
                }

                if(position==19){
                    Intent voca19 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern20.class);
                    context.startActivity(voca19);
                }


                if(position==20){
                    Intent voca20 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern21.class);
                    context.startActivity(voca20);
                }

                if(position==21){
                    Intent voca21 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern22.class);
                    context.startActivity(voca21);
                }

                if(position==22){
                    Intent voca22 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern23.class);
                    context.startActivity(voca22);
                }

                if(position==23){
                    Intent voca23 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern24.class);
                    context.startActivity(voca23);
                }

                if(position==24){
                    Intent voca24 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern25.class);
                    context.startActivity(voca24);
                }

                if(position==25){
                    Intent voca25 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern26.class);
                    context.startActivity(voca25);
                }

                if(position==26){
                    Intent voca26 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern27.class);
                    context.startActivity(voca26);
                }

                if(position==27){
                    Intent voca27 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern28.class);
                    context.startActivity(voca27);
                }

                if(position==28){
                    Intent voca28 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern29.class);
                    context.startActivity(voca28);
                }


                if(position==29){
                    Intent voca29 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern30.class);
                    context.startActivity(voca29);
                }

                if(position==30){
                    Intent voca30 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern31.class);
                    context.startActivity(voca30);
                }

                if(position==31){
                    Intent voca31 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern32.class);
                    context.startActivity(voca31);
                }

                if(position==32){
                    Intent voca32 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern33.class);
                    context.startActivity(voca32);
                }

                if(position==33){
                    Intent voca33 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern34.class);
                    context.startActivity(voca33);
                }


                if(position==34){
                    Intent voca34 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern35.class);
                    context.startActivity(voca34);
                }


                if(position==35){
                    Intent voca35 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern36.class);
                    context.startActivity(voca35);
                }

                if(position==36){
                    Intent voca36 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern37.class);
                    context.startActivity(voca36);
                }

                if(position==37){
                    Intent voca37 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern38.class);
                    context.startActivity(voca37);
                }

                if(position==38){
                    Intent voca38 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern39.class);
                    context.startActivity(voca38);
                }

                if(position==39){
                    Intent voca39 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern40.class);
                    context.startActivity(voca39);
                }

                if(position==40){
                    Intent voca40 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern41.class);
                    context.startActivity(voca40);
                }

                if(position==41){
                    Intent voca41 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern42.class);
                    context.startActivity(voca41);
                }

                if(position==42){
                    Intent voca42 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern43.class);
                    context.startActivity(voca42);
                }


                if(position==43){
                    Intent voca43 = new Intent(v.getContext(), moemoetun.com.shwedailyenglish.pattern44.class);
                    context.startActivity(voca43);
                }

            }
        });
        return rowView;
    }




}