package moemoetun.com.shwedailyenglish;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class eating_out extends AppCompatActivity {


    String [] friends= {


            "✪ 1.where_to_eat",
            "✪ 2.Spicy_Is_the Best",
            "✪ 3.popular_hot_dog",
            "✪ 4.A new item",
            "✪ 5.Waiting Outside",
            "✪ 6.Getting a Sandwich",
            "✪ 7.The Picky Eater",
            "✪ 8.Out of Iced Tea",
            "✪ 9.Allergic",
            "✪ 10.This Chicken Is So Plain",
            "✪ 11.Food Poisoning",
            "✪ 12. Breakfast for Dinner"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_eating_out);

        ListView listView = (ListView) findViewById(R.id.ListView_eating_out);

        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, friends );

        listView.setAdapter(adapter);

        //get itemClick
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                String friends = (String) adapterView.getItemAtPosition(position);
                Toast.makeText(view.getContext(),"Hello" +friends+ "", Toast.LENGTH_SHORT).show();


                if(position==0){
                    Intent voca1 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout1.class);
                    startActivity(voca1);
                }

                if(position==1){
                    Intent voca2 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout2.class);
                    startActivity(voca2);
                }


                if(position==2){
                    Intent voca3 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout3.class);
                    startActivity(voca3);
                }

                if(position==3){
                    Intent voca4 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout4.class);
                    startActivity(voca4);
                }

                if(position==4){
                    Intent voca5 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout5.class);
                    startActivity(voca5);
                }

                if(position==5){
                    Intent voca6 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout6.class);
                    startActivity(voca6);
                }

                if(position==6){
                    Intent voca7 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout7.class);
                    startActivity(voca7);
                }

                if(position==7){
                    Intent voca8 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout8.class);
                    startActivity(voca8);
                }

                if(position==8){
                    Intent voca9 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout9.class);
                    startActivity(voca9);
                }
                if(position==9){
                    Intent voca10 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout10.class);
                    startActivity(voca10);
                }

                if(position==10){
                    Intent voca11 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout11.class);
                    startActivity(voca11);
                }

                if(position==11){
                    Intent voca12 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.eatout12.class);
                    startActivity(voca12);
                }

            }
        });
    }

}
