package moemoetun.com.shwedailyenglish;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
public class Bus extends AppCompatActivity {


    String [] friends= {


            "✪ Bus Lines",
            "✪ Bus Schedule",
            "✪ Alternate Bus Route",
            "✪ Bus Tickets",
            "✪ Mini Bus",
            "✪ Discounts",
            "✪ So Many Bus Lines",
            "✪ Bus Route",
            "✪ Buying Tickets on The Bus",
            "✪ Falling Asleep On the Bus"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_bus);

        ListView listView = (ListView) findViewById(R.id.ListView_bus);


        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, friends );

        listView.setAdapter(adapter);

        //get itemClick
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                String friends = (String) adapterView.getItemAtPosition(position);
                Toast.makeText(view.getContext(),"Hello" +friends+ "", Toast.LENGTH_SHORT).show();


                if(position==0){
                    Intent voca1 = new Intent(view.getContext(),bus_line.class);
                    startActivity(voca1);
                }

                if(position==1){
                    Intent voca2 = new Intent(view.getContext(),BusSchedule.class);
                    startActivity(voca2);
                }

                if(position==2){
                    Intent voca3 = new Intent(view.getContext(),AlternateBusRoute.class);
                    startActivity(voca3);
                }

                if(position==3){
                    Intent voca4 = new Intent(view.getContext(),bus_ticket.class);
                    startActivity(voca4);
                }

                if(position==4){
                    Intent voca5 = new Intent(view.getContext(),mini_bus.class);
                    startActivity(voca5);
                }


                if(position==5){
                    Intent voca6 = new Intent(view.getContext(),discounts.class);
                    startActivity(voca6);
                }
                if(position==6){
                    Intent voca7 = new Intent(view.getContext(),somanybusline.class);
                    startActivity(voca7);
                }

                if(position==7){
                    Intent voca8 = new Intent(view.getContext(),bus_route.class);
                    startActivity(voca8);
                }

                if(position==8){
                    Intent voca9 = new Intent(view.getContext(),buyingticketonthebus.class);
                    startActivity(voca9);
                }

                if(position==9){
                    Intent voca10 = new Intent(view.getContext(),falling_asleep.class);
                    startActivity(voca10);
                }


            }
        });
    }

}
