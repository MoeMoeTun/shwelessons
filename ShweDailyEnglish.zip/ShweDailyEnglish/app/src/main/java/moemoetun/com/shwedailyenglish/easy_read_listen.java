package moemoetun.com.shwedailyenglish;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;

public class easy_read_listen  extends AppCompatActivity {

    ListView lv;
    Context context;


    ArrayList prgmName;
    public static int [] prgmImages={
            R.drawable.star,
            R.drawable.star1,R.drawable.star2,
            R.drawable.star3,R.drawable.star4,
            R.drawable.star5,R.drawable.star6,
            R.drawable.star7,R.drawable.star,
            R.drawable.star,R.drawable.star,


    };


    public static String [] prgmNameList={
            "✪ A baby boy and a sock",
            "✪ A cat and a dog",
            "✪ An Apple pie",
            "✪ Birds and a baby",
            "✪ Birthday bike",
            "✪ Boys will be boys",
            "✪ In the garden",
            "✪ No food, no job",
            "✪ No friend for me",
            "✪ Tell the truth",
            "✪ The baby bear"
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.easy_read_listen);



        MobileAds.initialize(getApplicationContext(), "ca-app-pub-4137439985376631/8428273307");
        AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        context=this;

        lv=(ListView) findViewById(R.id.listView_easy_read);
        lv.setAdapter(new CustomAdapter12(this, prgmNameList,prgmImages));


    }

}
