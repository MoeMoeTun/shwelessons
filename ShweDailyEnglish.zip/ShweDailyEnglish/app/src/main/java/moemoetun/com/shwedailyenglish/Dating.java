package moemoetun.com.shwedailyenglish;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Dating extends AppCompatActivity {


    String [] friends= {


            "✪ Should I....?",
            "✪ Dating Two People",
            "✪ Personality",
            "✪ Forgotten Anniversary",
            "✪ Paying the Restaurant Bill",
            "✪ Stood Up",
            "✪ Money Lover",
            "✪ Date Locations",
            "✪ Breaking Up",
            "✪ Dating After College",
            "✪ A Bad Boyfriend",
            "✪ The First Kiss"


    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_dating);


        ListView listView = (ListView) findViewById(R.id.ListView_dating);


        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, friends );

        listView.setAdapter(adapter);

        //get itemClick
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                String friends = (String) adapterView.getItemAtPosition(position);
                Toast.makeText(view.getContext(),"Hello" +friends+ "", Toast.LENGTH_SHORT).show();


                if(position==0){
                    Intent voca1 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating1.class);
                    startActivity(voca1);
                }

                if(position==1){
                    Intent voca2 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating2.class);
                    startActivity(voca2);
                }


                if(position==2){
                    Intent voca3 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating3.class);
                    startActivity(voca3);
                }

                if(position==3){
                    Intent voca4 = new Intent(view.getContext(),
                            moemoetun.com.shwedailyenglish.dating4.class);
                    startActivity(voca4);
                }

                if(position==4){
                    Intent voca5 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating5.class);
                    startActivity(voca5);
                }

                if(position==5){
                    Intent voca6 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating6.class);
                    startActivity(voca6);
                }

                if(position==6){
                    Intent voca7 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating7.class);
                    startActivity(voca7);
                }

                if(position==7){
                    Intent voca8 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating8.class);
                    startActivity(voca8);
                }

                if(position==8){
                    Intent voca9 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating9.class);
                    startActivity(voca9);
                }
                if(position==9){
                    Intent voca10 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating10.class);
                    startActivity(voca10);
                }

                if(position==10){
                    Intent voca11 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating11.class);
                    startActivity(voca11);
                }

                if(position==11){
                    Intent voca12 = new Intent(view.getContext(), moemoetun.com.shwedailyenglish.dating12.class);
                    startActivity(voca12);
                }


            }
        });
    }

}
