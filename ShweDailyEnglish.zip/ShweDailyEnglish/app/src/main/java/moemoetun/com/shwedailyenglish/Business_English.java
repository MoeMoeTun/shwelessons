package moemoetun.com.shwedailyenglish;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

public class Business_English extends AppCompatActivity {


    String [] friends= {


            "✪ Interview Question&Answer",
            "✪ Tell me about yourself",
            "✪ Are you an organized person?",
            "✪ Do you manage time well?",
            "✪ Do you work well under the pressure?",
            "✪ How do you handle changes?",
            "✪ How do you make important decisions?",
            "✪ If you could change one thing, what would it be?",
            "✪ In what way are you organized and disorganize?",
            "✪ What are you long term goals?",
            "✪ What are your short term goals?",
            "✪ What are your strengths?",
            "✪ What are your weaknesses?",
            "✪ What does failure mean to you?",
            "✪ What does success mean to you?",
            "✪ What will you be doing five years from now?",

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_business__english);


        MobileAds.initialize(getApplicationContext(), "ca-app-pub-4137439985376631/8428273307");
        AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        ListView listView = (ListView) findViewById(R.id.business_listview);


        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, friends );

        listView.setAdapter(adapter);

        //get itemClick
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                String friends = (String) adapterView.getItemAtPosition(position);
                Toast.makeText(view.getContext(),"Hello" +friends+ "", Toast.LENGTH_SHORT).show();


                if(position==2){
                    Intent voca3 = new Intent(view.getContext(), business0.class);
                    startActivity(voca3);
                }

                if(position==3){
                    Intent voca4 = new Intent(view.getContext(), business1.class);
                    startActivity(voca4);
                }


                if(position==4){
                    Intent voca4 = new Intent(view.getContext(), business2.class);
                    startActivity(voca4);
                }


                if(position==5){
                    Intent voca4 = new Intent(view.getContext(), business3.class);
                    startActivity(voca4);
                }




            }
        });
    }



}
